-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: sproject
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `inquiry`
--

DROP TABLE IF EXISTS `inquiry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inquiry` (
  `ino` int NOT NULL AUTO_INCREMENT,
  `iid` varchar(45) NOT NULL,
  `iname` varchar(45) DEFAULT NULL,
  `ititle` varchar(45) DEFAULT NULL,
  `icontent` varchar(100) DEFAULT NULL,
  `ipw` varchar(45) DEFAULT NULL,
  `iemail` varchar(45) NOT NULL,
  `idate` datetime DEFAULT NULL,
  `ianswer` varchar(100) DEFAULT NULL,
  `iadate` datetime DEFAULT NULL,
  `idel` int NOT NULL DEFAULT '0',
  `idiv` varchar(45) NOT NULL,
  PRIMARY KEY (`ino`,`iid`),
  KEY `id_idx` (`iid`),
  CONSTRAINT `iiid` FOREIGN KEY (`iid`) REFERENCES `member` (`mid`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inquiry`
--

LOCK TABLES `inquiry` WRITE;
/*!40000 ALTER TABLE `inquiry` DISABLE KEYS */;
INSERT INTO `inquiry` VALUES (1,'r1','','문의합니다.','혹시 00도서 어떻게 구할까요?',NULL,'spring@naver.com','2024-07-17 14:37:03','도서요청하기 서비스를 이용해보세요.','2024-07-18 14:37:03',0,'Q1'),(2,'r1','','반품문의','반품 어떻게 하나요?',NULL,'spring@naver.com','2024-07-17 16:35:51',NULL,NULL,0,'Q2'),(3,'none','익명이','익명 문의','가입을 못 하겠어요.',NULL,'1@naver.com','2024-07-17 17:17:59','고객센터로 연락주시면 도와드리겠습니다.','2024-07-18 14:38:03',0,'Q5'),(4,'none','궁금해','이메일분실','이메일을 분실했어요.',NULL,'1@naver.com','2024-07-17 17:23:13',NULL,NULL,0,'Q0'),(5,'r1','','도서문의','상품번호 1359 언제 입고되나요?',NULL,'spring@naver.com','2024-07-17 17:26:29',NULL,NULL,0,'Q1'),(6,'r1','','재문의','상품번호 1359 언제 입고되나요?',NULL,'spring@naver.com','2024-07-17 17:31:26',NULL,NULL,1,'Q1'),(7,'none','하이','알고 싶어요','홈페이지 어디 외주 맡기셨나요?',NULL,'1@naver.com','2024-07-17 17:31:50',NULL,NULL,0,'Q5'),(8,'none','김길동','매일','책이 갖고 싶은 데 돈이 없어요.','1354','1@naver.com','2024-07-17 17:38:56',NULL,NULL,0,'Q0'),(9,'r1','','문의','제 메일 주소가 이게 아닌데요?',NULL,'spring@naver.com','2024-07-17 17:39:19',NULL,NULL,1,'Q0'),(10,'none','홍길동','결재취소','결재 취소 방법은?','1234','1@naver.com','2024-07-18 12:02:04',NULL,NULL,0,'Q3'),(11,'none','김김이','제 돈','결재 취소 했는 데 돈 언제 들어오나요?',NULL,'1@naver.com','2024-07-18 12:10:13',NULL,NULL,0,'Q3'),(12,'none','이이이','홈페이지 오류','\'오류번호1\'이라고 뜨는 데 무슨 오륜가요?',NULL,'1@naver.com','2024-07-18 12:13:57',NULL,NULL,0,'Q4'),(13,'none','서서서','???','00도서는 어딧나요?',NULL,'1@naver.com','2024-07-18 12:15:15',NULL,NULL,0,'Q1'),(14,'none','우우우','익명 문의','주문번호 12354 - 책 언제 와요?',NULL,'1@naver.com','2024-07-18 12:27:09',NULL,NULL,0,'Q2'),(15,'none','닉네임','회원가입시','회원가입 시 개인정보가 꼭 필요하나요?','1234','rkrk@naver.com','2024-07-18 14:20:31',NULL,NULL,0,'Q5'),(16,'r1','회원1','등급문의','등급기준이 뭔가요?',NULL,'spring@naver.com','2024-07-18 14:32:25',NULL,NULL,0,'Q5'),(17,'none','닉네임','익명 문의','문의할게 없어요.','1234','rkrk@naver.com','2024-07-25 12:22:22',NULL,NULL,1,'Q5');
/*!40000 ALTER TABLE `inquiry` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-02 15:41:03
