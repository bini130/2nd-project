-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: sproject
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notice`
--

DROP TABLE IF EXISTS `notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notice` (
  `nnum` int NOT NULL AUTO_INCREMENT,
  `nuser` varchar(45) DEFAULT NULL,
  `ntitle` varchar(45) NOT NULL,
  `ncontent` varchar(500) DEFAULT NULL,
  `ndate` datetime DEFAULT NULL,
  `nfilereal` varchar(500) DEFAULT NULL,
  `nfilefake` varchar(500) DEFAULT NULL,
  `npicturereal` varchar(500) DEFAULT NULL,
  `npicturefake` varchar(500) DEFAULT NULL,
  `npicturetype` varchar(45) DEFAULT NULL,
  `nclass` int DEFAULT NULL,
  `nlength` int DEFAULT NULL,
  `nwidth` int DEFAULT NULL,
  `nstartdate` datetime DEFAULT NULL,
  `nenddate` datetime DEFAULT NULL,
  `ndel` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`nnum`),
  KEY `id_idx` (`nuser`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice`
--

LOCK TABLES `notice` WRITE;
/*!40000 ALTER TABLE `notice` DISABLE KEYS */;
INSERT INTO `notice` VALUES (1,'총괄','제목','07/03오픈!','2024-06-01 00:00:00',NULL,NULL,'png세요_.png','1721372173238.png',NULL,1,NULL,NULL,'2024-07-03 00:00:00','2024-07-31 00:00:00',0),(4,'총괄','팝업2','어쩌구저쩌구','2024-07-12 00:00:00',NULL,NULL,NULL,NULL,NULL,0,200,200,'2024-07-12 00:00:00','2024-07-30 00:00:00',1),(6,'이벤트','이벤트','이벤트','2024-07-19 09:53:42','제목을 입력해주세요_.zip','1721349728215.zip','10p.png','1721349728217.png',NULL,2,0,0,'2024-07-24 00:00:00','2024-07-31 00:00:00',0),(7,'공지','공지','공지','2024-07-19 10:06:17',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'2024-07-25 02:10:00','2024-07-09 02:10:00',0),(8,'전문가','신규 입고 책 안내','신규 책 안내드립니다.\r\n1. 2024 큰별쌤 최태성의 별★별한국사 한국사능력검정시험 심화(1, 2, 3급) 상\r\n2. 혼자공부 메타 스터디 플래너 가로형 (4개월용)\r\n3. 누가 내 머리에 똥 쌌어?','2024-07-19 10:14:42',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'2024-07-19 10:18:00','2024-07-29 03:19:00',0),(9,'공지','공지사항','등록','2024-07-19 10:16:54','pointtitle.png','1721879132913.png','pointtitle.png','1721879240441.png',NULL,1,NULL,NULL,'2024-07-19 10:16:00','2024-07-24 02:20:00',1),(12,'관리자','신규 책 안내 - 돼지 책','신규 책을 확인해보세요.','2024-07-19 11:03:05','제목을 입력해주세요_.zip','1721370288242.zip','book2.png','1722320862130.png',NULL,1,NULL,NULL,'2024-07-19 11:03:05','2024-07-24 02:20:00',1),(13,'수정','수정','수정','2024-07-19 16:28:19',NULL,NULL,'1000p.png','1721375161705.png',NULL,0,500,500,'2024-07-17 16:28:00','2024-07-19 23:59:59',0),(15,'멋쟁이','지금 당장 포인트 적립 하세요!','지금 당장 포인트 적립!','2024-07-19 16:32:45',NULL,NULL,'pointimg.jpg','1721374365505.jpg',NULL,0,300,300,'2024-07-22 16:32:00','2024-08-30 16:32:00',0),(16,'키다리',' [누가 내 머리에 똥 쌌어] 추가 발매','나를 뽑아줘~','2024-07-25 12:55:05',NULL,NULL,'22.PNG','1722320905910.PNG',NULL,0,500,500,'2024-07-24 00:01:00','2024-08-08 23:59:00',0),(17,'책지기','정보처리기사 책 추가 문의','문의 : 031 444 4444','2024-07-30 15:31:56','bookad2.jpg','1722321116610.jpg',NULL,NULL,NULL,1,NULL,NULL,'2024-07-30 15:31:56','2024-07-24 02:20:00',0);
/*!40000 ALTER TABLE `notice` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-02 15:41:02
