-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: sproject
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `nonmemaddress`
--

DROP TABLE IF EXISTS `nonmemaddress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nonmemaddress` (
  `nonno` int NOT NULL,
  `nonpostal` varchar(45) DEFAULT NULL,
  `nonaddress` varchar(45) DEFAULT NULL,
  `nondetail` varchar(45) DEFAULT NULL,
  `nondong` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`nonno`),
  CONSTRAINT `nonno` FOREIGN KEY (`nonno`) REFERENCES `buy` (`buyno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nonmemaddress`
--

LOCK TABLES `nonmemaddress` WRITE;
/*!40000 ALTER TABLE `nonmemaddress` DISABLE KEYS */;
INSERT INTO `nonmemaddress` VALUES (13,'16661','경기 수원시 권선구 경수대로 14','테스트 1',' (대황교동)'),(14,'16661','경기 수원시 권선구 경수대로 14','테스트 1',' (대황교동)'),(15,'16661','경기 수원시 권선구 경수대로 14','1234',' (대황교동)'),(18,'16661','경기 수원시 권선구 경수대로 14','1234',' (대황교동)'),(19,'16661','경기 수원시 권선구 경수대로 14','1234',' (대황교동)'),(22,'16661','경기 수원시 권선구 대황교동 59-4','1234',''),(23,'16661','경기 수원시 권선구 대황교동 59-4','1234',''),(24,'16661','경기 수원시 권선구 대황교동 59-4','1234',''),(25,'16661','경기 수원시 권선구 경수대로 14','123',' (대황교동)'),(26,'16661','경기 수원시 권선구 경수대로 14','123',' (대황교동)'),(27,'16661','경기 수원시 권선구 경수대로 14','123',' (대황교동)'),(28,'16661','경기 수원시 권선구 경수대로 14','123',' (대황교동)'),(29,'16661','경기 수원시 권선구 경수대로 14','123',' (대황교동)'),(30,'11611','경기 의정부시 가능동 96-1','1234',''),(31,'11611','경기 의정부시 가능동 96-1','1234',''),(32,'11611','경기 의정부시 가능동 96-1','1234',''),(33,'11611','경기 의정부시 가능동 96-1','1234',''),(34,'11611','경기 의정부시 가능동 96-1','1234',''),(35,'11611','경기 의정부시 가능동 96-1','1234',''),(36,'11611','경기 의정부시 가능동 96-1','1234',''),(37,'11611','경기 의정부시 가능동 96-1','1234',''),(41,'11611','경기 의정부시 가금로 29','1234',' (가능동)'),(42,'12427','경기 가평군 가평읍 가랫골길 5','1234',''),(43,'11684','경기 의정부시 가금로 53','1234',' (가능동)'),(44,'11684','경기 의정부시 가금로 53','1234',' (가능동)'),(45,'06719','서울 서초구 반포대로 4','1234',' (서초동)'),(48,'16661','경기 수원시 권선구 경수대로 83','아파트 1층',' (대황교동)'),(49,'','','123',''),(50,'10488','경기 고양시 덕양구 수원문산고속도로 49','1234',' (도내동)'),(51,'16221','경기 수원시 장안구 경수대로 748','1234',' (연무동)'),(53,'28574','충북 청주시 서원구 1순환로 632','123',' (사창동)'),(58,'06763','서울 서초구 바우뫼로 2','1233',' (우면동, 씨마빌)'),(59,'06763','서울 서초구 바우뫼로 2','1233',' (우면동, 씨마빌)'),(61,'05517','서울 송파구 풍납동 126-179','123',''),(62,'05517','서울 송파구 바람드리길 6-3','123',' (풍납동)'),(63,'06763','서울 서초구 우면동 1','123',''),(64,'05517','서울 송파구 바람드리길 6-3','qwe',' (풍납동)'),(65,'06763','서울 서초구 바우뫼로 10','123',' (우면동, 동부그린빌라)'),(66,'06763','서울 서초구 바우뫼로 2','123',' (우면동, 씨마빌)'),(67,'06688','서울 서초구 방배동 978-9','123',''),(68,'05517','서울 송파구 바람드리길 6-7','123',' (풍납동)'),(69,'05237','서울 강동구 아리수로 46','1234',' (암사동)'),(70,'05237','서울 강동구 아리수로 46','1234',' (암사동)'),(71,'28322','충북 청주시 청원구 1순환로 42','123',' (율량동)'),(72,'28322','충북 청주시 청원구 1순환로 42','123',' (율량동)'),(73,'06763','서울 서초구 바우뫼로 10','3',' (우면동, 동부그린빌라)'),(74,'06763','서울 서초구 바우뫼로 10','ㅂㅈㄷ',' (우면동, 동부그린빌라)'),(75,'06763','서울 서초구 바우뫼로 10','qwe',' (우면동, 동부그린빌라)'),(76,'06763','서울 서초구 바우뫼로 10','qwe',' (우면동, 동부그린빌라)'),(77,'28574','충북 청주시 서원구 1순환로 632','123',' (사창동)'),(78,'16661','경기 수원시 권선구 경수대로 14','테스트1',' (대황교동)'),(79,'16661','경기 수원시 권선구 경수대로 14','테스트1',' (대황교동)'),(81,'16661','경기 수원시 권선구 경수대로 14','테스트1',' (대황교동)'),(84,'16661','경기 수원시 권선구 경수대로 14','1234',' (대황교동)'),(85,'16661','경기 수원시 권선구 경수대로 14','1234',' (대황교동)');
/*!40000 ALTER TABLE `nonmemaddress` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-02 15:41:03
