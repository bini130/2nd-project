-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: sproject
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `codetable`
--

DROP TABLE IF EXISTS `codetable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `codetable` (
  `codeid` varchar(45) NOT NULL,
  `pid` varchar(45) NOT NULL,
  `pname` varchar(45) DEFAULT NULL,
  `pyorn` varchar(45) DEFAULT 'Y,N',
  `codename` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`pid`,`codeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `codetable`
--

LOCK TABLES `codetable` WRITE;
/*!40000 ALTER TABLE `codetable` DISABLE KEYS */;
INSERT INTO `codetable` VALUES ('bocodeId','A0','bocode','Y','기본'),('bocodeId','A1','bocode','Y','광고'),('bocodeId','A2','bocode','Y','신작'),('bocodeId','A3','bocode','Y','요청'),('bocodeId','A4','bocode','Y','업체요청'),('deliveryId','B0','dtransport','N','반품신청'),('deliveryId','B1','dtransport','N','반품처리중'),('deliveryId','B10','dtransport','Y','결제대기'),('deliveryId','B11','dtransport','Y','주문완료'),('deliveryId','B12','dtransport','Y','결제완료'),('deliveryId','B13','dtransport','Y','구매확정'),('deliveryId','B14','dtransport','N','반품완료'),('deliveryId','B15','dtransport','Y','환불처리중'),('deliveryId','B18','dtransport','Y','취소신청'),('deliveryId','B19','dtransport','Y','취소처리중'),('deliveryId','B2','dtransport','Y','교환신청'),('deliveryId','B20','dtransport','Y','취소완료'),('deliveryId','B3','dtransport','Y','교환처리중'),('deliveryId','B4','dtransport','Y','교환완료'),('deliveryId','B5','dtransport','Y','배송준비중'),('deliveryId','B6','dtransport','Y','배송중'),('deliveryId','B7','dtransport','Y','배송완료'),('deliveryId','B8','dtransport','Y','환불완료'),('deliveryId','B9','dtransport','Y','환불신청'),('genreId','C0','bogenre','Y','소설'),('genreId','C1','bogenre','Y','인문학'),('genreId','C2','bogenre','Y','문구'),('genreId','C3','bogenre','Y','에세이'),('genreId','C4','bogenre','Y','수험서'),('genreId','C5','bogenre','Y','그림책'),('genreId','C6','bogenre','Y','경제'),('marketingId','D0','moptional','Y','비동의'),('marketingId','D1','moptional','Y','앱푸시'),('marketingId','D2','moptional','Y','문자/카톡'),('marketingId','D3','moptional','Y','이메일'),('marketingId','D4','moptional','Y','앱푸시+이메일'),('marketingId','D5','moptional','Y','문자/카톡+이메일'),('marketingId','D6','moptional','Y','전체동의'),('marketingId','D7','moptional','Y','앱푸시+문자/카톡'),('paymentId','E0','buycode','Y','결제대기중'),('paymentId','E1','buycode','Y','결제확인중'),('paymentId','E2','buycode','Y','결제완료'),('pointId','F0','mpoint','Y','플래티넘'),('pointId','F1','mpoint','Y','실버'),('pointId','F2','mpoint','Y','골드'),('reportId','G0','reportreason','Y','스팸홍보/도배'),('reportId','G1','reportreason','Y','음란물'),('reportId','G2','reportreason','Y','불법정보포함'),('reportId','G3','reportreason','Y','청소년 유해 내용'),('reportId','G4','reportreason','Y','기타'),('situationId','H0','mstate','Y','가입자'),('situationId','H2','mstate','Y','탈퇴'),('situationId','H3','mstate','Y','정지'),('situationId','H4','mstate','Y','강제탈퇴'),('inquiryId','Q0','QnA','Y','개인정보관련문의'),('inquiryId','Q1','QnA','Y','도서관련문의'),('inquiryId','Q2','QnA','Y','주문관련문의'),('inquiryId','Q3','QnA','Y','결재관련문의'),('inquiryId','Q4','QnA','Y','홈페이지오류문의'),('inquiryId','Q5','QnA','Y','기타문의'),('paymentId','W0','payment','Y','카드 결제'),('paymentId','W1','payment','Y','무통장 입금'),('paymentId','W2','payment','Y','간편 결제');
/*!40000 ALTER TABLE `codetable` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-02 15:41:03
