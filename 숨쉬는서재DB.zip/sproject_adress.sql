-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: sproject
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `adress`
--

DROP TABLE IF EXISTS `adress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `adress` (
  `ano` int NOT NULL,
  `aid` varchar(45) NOT NULL,
  `apostal` varchar(45) DEFAULT NULL,
  `aadress` varchar(45) DEFAULT NULL,
  `adong` varchar(45) DEFAULT NULL,
  `adetail` varchar(45) DEFAULT NULL,
  `adel` varchar(45) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ano`,`aid`),
  KEY `aid_idx` (`aid`),
  CONSTRAINT `aid` FOREIGN KEY (`aid`) REFERENCES `member` (`mid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adress`
--

LOCK TABLES `adress` WRITE;
/*!40000 ALTER TABLE `adress` DISABLE KEYS */;
INSERT INTO `adress` VALUES (0,'none',NULL,NULL,NULL,NULL,'0'),(1,'a123123','01810','서울 노원구 공릉로 264',' (하계동)','101호','0'),(1,'r1','03062','서울 종로구 삼청로 4',' (사간동)','','0'),(1,'r2','2080','수원시 메산동',NULL,'5층','0'),(1,'test','04117','서울 마포구 굴레방로 1',' (아현동)','','0'),(1,'test666','03715','서울 서대문구 수색로 17',' (남가좌동)','','0'),(2,'r1','01660','서울 노원구 수락산로 9',' (상계동)','','0'),(2,'r2','05831','서울 송파구 동남로 99',' (가락동)','1234','0'),(3,'r1','03753','서울 서대문구 경기대로 9',' (충정로3가)','1234','0'),(3,'r2','05768','서울 송파구 거마로 6',' (거여동)','','0'),(4,'r1','16661','경기 수원시 권선구 경수대로 14',' (대황교동)','1234444','0'),(5,'r1','16661','경기 수원시 권선구 경수대로 14',' (대황교동)','1234','0'),(6,'r1','16221','경기 수원시 장안구 경수대로 748',' (연무동)','1234','0');
/*!40000 ALTER TABLE `adress` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-02 15:41:03
